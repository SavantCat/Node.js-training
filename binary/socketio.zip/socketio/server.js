var socketIO = require('socket.io');
var io = socketIO.listen(110);

console.log("Start server");


io.sockets.on('connection', function(socket) {
    var address = socket.handshake.address;
    console.log("New connection from " + socket.id);
  // メッセージを受けたときの処理
  socket.on('message', function(data) {
    // つながっているクライアント全員に送信
    console.log("message:"+data);
    io.sockets.emit('message',data);
  });

  // クライアントが切断したときの処理
  socket.on('disconnect', function(){
    console.log("disconnect");
  });
});