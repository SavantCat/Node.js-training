var io = require('socket.io-client');
var socket = io.connect('http://118.111.94.92:110');

socket.on('connect', function(){
    
});
socket.on('message', function(data){
    console.log(data);
});
socket.on('disconnect', function(){
    
});

process.stdin.resume();
process.stdin.setEncoding('utf8');

// 標準入力がくると発生するイベント
process.stdin.on('data', function (chunk) {
    chunk.trim().split('\n').forEach(function(line) {
        // 1行ずつ表示
        console.log('>' + line);
        socket.send(line);
    });
});
// EOFがくると発生するイベント
process.stdin.on('end', function (data) {
    
});